import streamlit as st
import pandas as pd

st.set_page_config(
    page_title="QuantEdge",
    page_icon="📈",
    layout="wide",
)

st.title("📈 QuantEdge")
st.caption("Research & backtesting foundation • Paper trading only")

st.subheader("1. Upload Market Data")

uploaded_file = st.file_uploader(
    "Upload an OHLCV CSV file",
    type=["csv"],
    help="Required: Open, High, Low, Close, Volume. Date/Datetime/Timestamp is optional.",
)

if uploaded_file is None:
    st.info("Upload a CSV to begin.")
    st.stop()

try:
    df = pd.read_csv(uploaded_file)
except Exception as e:
    st.error(f"Could not read the CSV: {e}")
    st.stop()

# Normalize column names while preserving the original data.
df.columns = [str(c).strip() for c in df.columns]

required = ["Open", "High", "Low", "Close", "Volume"]
missing = [c for c in required if c not in df.columns]

if missing:
    st.error("Missing required columns: " + ", ".join(missing))
    st.write("Required columns:", ", ".join(required))
    st.write("Columns found:", ", ".join(df.columns))
    st.stop()

for col in required:
    df[col] = pd.to_numeric(df[col], errors="coerce")

bad_rows = int(df[required].isna().any(axis=1).sum())

st.success(f"CSV loaded successfully • {len(df):,} rows")

if bad_rows:
    st.warning(f"{bad_rows:,} rows contain invalid/missing OHLCV values.")

c1, c2, c3 = st.columns(3)
c1.metric("Rows", f"{len(df):,}")
c2.metric("Columns", f"{len(df.columns):,}")
c3.metric("Invalid OHLCV rows", f"{bad_rows:,}")

st.subheader("2. Data Preview")
st.dataframe(df.head(25), use_container_width=True)

st.caption("QuantEdge foundation is working. Strategy and backtesting modules will be added only after this foundation is verified.")
