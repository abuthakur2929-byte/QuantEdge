# QuantEdge

Phone-friendly research and backtesting application.

## Current version

Foundation only:

- Streamlit UI
- OHLCV CSV upload
- Required-column validation
- Numeric data validation
- Data preview
- No live broker orders

## CSV format

Required columns:

- Open
- High
- Low
- Close
- Volume

Optional:

- Date
- Datetime
- Timestamp

## Run

```bash
pip install -r requirements.txt
streamlit run app.py
```

Next phases will add indicators, market-regime detection, signal scoring, backtesting, risk management, and performance analytics.
